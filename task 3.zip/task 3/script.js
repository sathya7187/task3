let display = document.getElementById('display');
let buttons = document.querySelectorAll('.button');

let calculator = {
    displayValue: '0',
    firstOperand: null,
    secondOperand: null,
    operator: null,
};

buttons.forEach(button => {
    button.addEventListener('click', () => {
        handleInput(button.value);
    });
});

function handleInput(input) {
    if (input === '=') {
        calculate();
    } else if (input === 'C') {
        resetCalculator();
    } else if (isNaN(input)) {
        handleOperator(input);
    } else {
        updateDisplay(input);
    }
}

function updateDisplay(input) {
    if (calculator.displayValue === '0') {
        calculator.displayValue = input;
    } else {
        calculator.displayValue += input;
    }
    display.value = calculator.displayValue;
}

function handleOperator(input) {
    calculator.firstOperand = parseFloat(calculator.displayValue);
    calculator.operator = input;
    calculator.displayValue = '0';
}

function calculate() {
    calculator.secondOperand = parseFloat(calculator.displayValue);
    let result = 0;
    switch (calculator.operator) {
        case '+':
            result = calculator.firstOperand + calculator.secondOperand;
            break;
        case '-':
            result = calculator.firstOperand - calculator.secondOperand;
            break;
        case '*':
            result = calculator.firstOperand * calculator.secondOperand;
            break;
        case '/':
            result = calculator.firstOperand / calculator.secondOperand;
            break;
    }
    calculator.displayValue = result.toString();
    display.value = calculator.displayValue;
    resetCalculator();
}

function resetCalculator() {
    calculator.displayValue = '0';
    calculator.firstOperand = null;
    calculator.secondOperand = null;
    calculator.operator = null;
}